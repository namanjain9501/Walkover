from django.urls import path, include
from . import views

urlpatterns = [
    # path('register_user', UserRegisterView.as_view(), name="register"),
    path('', views.home, name="home"),
    path('login/', views.login_view, name="login"),
    path('register/', views.register, name="register"),
    path('logout/', views.logout_user, name="logout"),
    path('add_task/', views.add_assignment, name="add-task"),
    path('view_task/', views.view_task, name="view-task"),
    path('view_submission/<id>', views.view_submissions, name="view-submissions"),
    path('submit/<id>', views.submit, name="submit"),
    path('student_list', views.student_list, name="student-list"),
    path('update_student/<id>', views.update_student, name="update_student"),
    path('class', views.select_class, name="class"),
    path('delete_student/<id>', views.delete_student, name="delete-student"),
    path('teacher_list', views.teacher_list, name="teacher-list"),
    path('update_teacher/<id>', views.update_teacher, name="update-teacher"),
    
    
]

